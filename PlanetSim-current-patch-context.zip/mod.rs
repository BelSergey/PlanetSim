// src/domains/tectonics/mod.rs
<<<<<<< HEAD
=======

pub mod solver;
>>>>>>> upstream/dev
mod tectonics_config;
pub mod tectonics_data;
pub mod tectonics_evolution;
pub mod tectonics_palettes;
pub mod tectonics_ui;

#[allow(unused_imports)]
pub use solver::{
    finalize_tectonics,
    generate_hotspots,
    generate_plates,
    generate_plumes,
    init_tectonics,
    prepare_tectonics_scratch,
    simulate_tectonics,
    step_elevation_diffusion,
    step_tectonics,
    step_tectonics_realtime,
    TectonicsGeometryCache,
    TectonicsScratch,
};
pub use tectonics_config::TectonicsConfig;
pub use tectonics_data::GeologyLayer;
<<<<<<< HEAD
pub use tectonics_evolution::{
    TectonicEvolutionConfig, TectonicEvolutionState, tick_tectonic_evolution,
};
pub use tectonics_solver::{generate_hotspots, generate_plates, simulate_tectonics};
=======
>>>>>>> upstream/dev

use crate::world::pipeline::PipelineSet;
use bevy::prelude::*;

pub struct TectonicsPlugin;

impl Plugin for TectonicsPlugin {
    fn build(&self, app: &mut App) {
        app.init_resource::<TectonicsConfig>()
            .init_resource::<GeologyLayer>()
            .init_resource::<TectonicEvolutionConfig>()
            .init_resource::<TectonicEvolutionState>()
            .add_systems(
                Update,
                tick_tectonic_evolution.in_set(PipelineSet::Simulation),
            );
    }
}